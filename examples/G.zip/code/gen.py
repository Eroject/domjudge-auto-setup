#!/usr/bin/env python3
import random
import sys

def set_deterministic():
    """Ensure reproducible results"""
    random.seed(42)  # Fixed seed
    if sys.version_info >= (3, 11):
        random.randbytes(1)  # Python 3.11+ needs this for full determinism

def is_prime(n):
    if n < 2:
        return False
    for p in [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31]:
        if n % p == 0:
            return n == p
    d = n - 1
    s = 0
    while d % 2 == 0:
        d //= 2
        s += 1
    for a in [2, 325, 9375, 28178, 450775, 9780504, 1795265022]:
        if a >= n:
            continue
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True

def generate_test_case(t, x_max=10**9, k_max=7):
    print(t)
    for _ in range(t):
        if random.random() < 0.3:  # 30% chance to generate known primes
            primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
            x = random.choice(primes)
            k = random.randint(1, min(k_max, 3))  # Smaller k for actual primes
        else:
            x = random.randint(1, x_max)
            k = random.randint(1, k_max)
        print(x, k)

def main():
    if len(sys.argv) != 4:
        print("Usage: python gen.py [t] [max_x] [max_k]")
        print("Example: python gen.py 100 1000000000 7")
        sys.exit(1)

    set_deterministic()

    t = int(sys.argv[1])
    max_x = int(sys.argv[2])
    max_k = int(sys.argv[3])

    generate_test_case(t, max_x, max_k)

if __name__ == "__main__":
    main()