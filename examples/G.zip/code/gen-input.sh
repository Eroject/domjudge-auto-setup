#!/bin/bash


# Small test cases
python3 gen.py 5 100 3 > ../data/secret/01.in
python3 gen.py 5 1000 5 > ../data/secret/02.in

# Medium test cases
python3 gen.py 20 1000000 7 > ../data/secret/03.in
python3 gen.py 20 10000000 7 > ../data/secret/04.in

# Large test cases with known primes
python3 gen.py 20 1000000000 7 > ../data/secret/05.in
python3 gen.py 20 1000000000 7 > ../data/secret/06.in
