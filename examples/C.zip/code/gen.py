#!/usr/bin/env python3
import random
import sys

def generate_test_case():
    t = 10000  # Maximum number of test cases
    print(t)
    for _ in range(t):
        if random.random() < 0.2:
            # Generate edge cases (1,1), (1,1e9), etc.
            n = random.choice([1, 10**9])
            m = random.choice([1, 10**9])
        else:
            n = random.randint(1, 10**9)
            m = random.randint(1, 10**9)
        print(n, m)

if __name__ == "__main__":
    generate_test_case()
