#!/bin/bash
for test in ../data/*.in; do
    base=${test%.in}
    ./solution < $test > $base.ans
done

