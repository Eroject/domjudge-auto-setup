#!/bin/bash                                                                                                                                                     

sed -i 's/\r$//' gen-input.sh
sed -i 's/\r$//' gen-out.sh
set -e  # Arrêter le script si une commande échoue

# Rendre les fichiers exécutables
chmod +x gen.py
chmod +x gen-input.sh
chmod +x gen-out.sh

# Compilation du fichier C++
g++ -O2 -std=c++17 -o solution soultion.cpp

# Génération des entrées et sorties
./gen-input.sh
./gen-out.sh

echo "✅ Compilation et génération terminées."
