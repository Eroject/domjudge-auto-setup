#!/usr/bin/env python3
import random
import sys

def set_deterministic():
    """Ensure reproducible results"""
    random.seed(42)  # Fixed seed
    if sys.version_info >= (3, 11):
        random.randbytes(1)  # Python 3.11+ needs this for full determinism

def generate_test_case(t, n_max=1000, d_max=10**9, h_max=10**9):
    for _ in range(t):
        n = random.randint(2, n_max)
        d = random.randint(1, d_max)
        heights = [random.randint(1, h_max) for _ in range(n)]
        print(n, d)
        print(' '.join(map(str, heights)))

def main():
    if len(sys.argv) != 4:
        print("Usage: python gen.py [t] [max_n] [max_d]")
        print("Example: python gen.py 100 1000 1000000000")
        sys.exit(1)

    set_deterministic()

    t = int(sys.argv[1])
    max_n = int(sys.argv[2])
    max_d = int(sys.argv[3])

    print(t)
    generate_test_case(t, max_n, max_d)

if __name__ == "__main__":
    main()