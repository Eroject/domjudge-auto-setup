#include <bits/stdc++.h>
using namespace std;

void solve() {
    string s;
    cin >> s;
    int m;
    cin >> m;
    string l, r;
    cin >> l >> r;
    
    int n = s.size();
    int mx = 0;
    for (int i = 0; i < m; i++) {
        int li = l[i] - '0';
        int ri = r[i] - '0';
        int nmx = mx;
        for (int c = li; c <= ri; c++) {
            int cur = mx;
            while (cur < n && s[cur] - '0' != c) {
                cur++;
            }
            nmx = max(nmx, cur);
        }
        mx = nmx + 1;
    }
    cout << (mx > n ? "YES" : "NO") << '\n';
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t;
    cin >> t;
    while (t--) {
        solve();
    }
    
    return 0;
}
