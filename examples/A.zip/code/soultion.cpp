#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;

bool is_possible(const string& s, int m, const string& l, const string& r) {
    int n = s.size();
    vector<vector<int>> next_pos(n+2, vector<int>(10, n));
    
    // Precompute next positions for each digit
    for (int i = n-1; i >= 0; --i) {
        for (int d = 0; d < 10; ++d) {
            next_pos[i][d] = next_pos[i+1][d];
        }
        next_pos[i][s[i]-'0'] = i;
    }
    
    int current_pos = 0;
    for (int i = 0; i < m; ++i) {
        int low = l[i] - '0';
        int high = r[i] - '0';
        int max_next_pos = -1;
        
        for (int d = low; d <= high; ++d) {
            if (next_pos[current_pos][d] == n) {
                return true;  // Found a digit not in s
            }
            max_next_pos = max(max_next_pos, next_pos[current_pos][d]);
        }
        
        if (max_next_pos == -1) {
            return false;
        }
        current_pos = max_next_pos + 1;
    }
    
    return false;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t;
    cin >> t;
    while (t--) {
        string s;
        int m;
        string l, r;
        cin >> s >> m >> l >> r;
        
        cout << (is_possible(s, m, l, r) ? "YES" : "NO") << "\n";
    }
    
    return 0;
}