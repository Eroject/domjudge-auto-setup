#!/bin/bash
for test in ../data/secret/*.in; do
    base=${test%.in}
    ./solution < $test > $base.ans
done

