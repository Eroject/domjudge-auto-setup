#!/usr/bin/env python3
import random
import sys

def set_deterministic():
    """Ensure reproducible results"""
    random.seed(42)  # Fixed seed
    if sys.version_info >= (3, 11):
        random.randbytes(1)  # Python 3.11+ needs this for full determinism

def generate_test_case(t, s_max=3*10**5, m_max=10):
    print(t)
    for _ in range(t):
        # Generate password database
        s_len = random.randint(1, s_max)
        s = ''.join(str(random.randint(0, 9)) for _ in range(s_len))
        
        # Generate password constraints
        m = random.randint(1, m_max)
        l = ''.join(str(random.randint(0, 9)) for _ in range(m))
        r = ''.join(
            str(random.randint(max(0, int(l[i]) - 1), min(9, int(l[i]) + 1)))
            for i in range(m)
        )
        
        print(s)
        print(m)
        print(l)
        print(r)

def main():
    if len(sys.argv) != 2:
        print("Usage: python gen.py [t]")
        print("Example: python gen.py 100")
        sys.exit(1)

    set_deterministic()

    t = int(sys.argv[1])
    generate_test_case(t)

if __name__ == "__main__":
    main()
