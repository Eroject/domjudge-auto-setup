#!/bin/bash


# Small test cases
python3 gen.py 5 > ../data/secret/01.in
python3 gen.py 5 > ../data/secret/02.in

# Medium test cases
python3 gen.py 200 > ../data/secret/03.in
python3 gen.py 200 > ../data/secret/04.in

# Large test cases
python3 gen.py 500 > ../data/secret/05.in
python3 gen.py 1000 > ../data/secret/06.in