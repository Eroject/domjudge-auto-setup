#!/bin/bash

python3 gen.py 5 100 > ../data/secret/01.in
python3 gen.py 5 1000 > ../data/secret/02.in

# Medium test cases
python3 gen.py 20 100000 > ../data/secret/03.in
python3 gen.py 20 1000000 > ../data/secret/04.in

# Large test cases
python3 gen.py 801000000000 > ../data/secret/05.in
python3 gen.py 90 1000000000 > ../data/secret/06.in

