#!/usr/bin/env python3
import random
import sys
import math

def set_deterministic():
    """Ensure reproducible results"""
    random.seed(42)  # Fixed seed
    if sys.version_info >= (3, 11):
        random.randbytes(1)  # Python 3.11+ needs this for full determinism

def generate_test_case(t, n_max=10**9):
    print(t)
    for _ in range(t):
        # Generate a mix of special cases and random numbers
        if random.random() < 0.3:  # 30% chance for special cases
            case_type = random.randint(1, 4)
            if case_type == 1:  # n = 1
                print(1)
            elif case_type == 2:  # n = 2
                print(2)
            elif case_type == 3:  # n = prime > 2
                p = random.choice([3,5,7,11,13,17,19,23,29,31])
                print(p)
            else:  # n = 2 * prime
                p = random.choice([3,5,7,11,13,17,19,23,29,31])
                print(2 * p)
        else:
            n = random.randint(1, n_max)
            print(n)

def main():
    if len(sys.argv) != 3:
        print("Usage: python gen.py [t] [max_n]")
        print("Example: python gen.py 100 1000000000")
        sys.exit(1)

    set_deterministic()

    t = int(sys.argv[1])
    max_n = int(sys.argv[2])

    generate_test_case(t, max_n)

if __name__ == "__main__":
    main()