#!/usr/bin/env python3
import random
import sys
from collections import defaultdict

def set_deterministic():
    """Ensure reproducible results"""
    random.seed(42)  # Fixed seed
    if sys.version_info >= (3, 11):
        random.randbytes(1)  # Python 3.11+ needs this for full determinism

def generate_test_case(t, n_max=2*10**5, a_max=10**9):
    print(t)
    for _ in range(t):
        # Generate array with varying frequency distributions
        n = random.randint(1, min(n_max, 2*10**5))
        
        # Choose between different distribution types
        case_type = random.randint(1, 4)
        if case_type == 1:  # All unique elements
            a = random.sample(range(1, a_max+1), n)
        elif case_type == 2:  # Few unique elements, many duplicates
            unique = random.randint(1, min(10, n))
            a = [random.randint(1, a_max) for _ in range(unique)] * (n // unique)
            a += [random.randint(1, a_max) for _ in range(n % unique)]
            random.shuffle(a)
        elif case_type == 3:  # Nearly sorted array
            a = sorted([random.randint(1, a_max) for _ in range(n)])
            for _ in range(n//10):
                i, j = random.randint(0, n-1), random.randint(0, n-1)
                a[i], a[j] = a[j], a[i]
        else:  # Random array
            a = [random.randint(1, a_max) for _ in range(n)]
        
        print(n)
        print(' '.join(map(str, a)))

def main():
    if len(sys.argv) != 2:
        print("Usage: python gen.py [t]")
        print("Example: python gen.py 100")
        sys.exit(1)

    set_deterministic()

    t = int(sys.argv[1])
    generate_test_case(t)

if __name__ == "__main__":
    main()