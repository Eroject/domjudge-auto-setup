import random
import sys

def generate_super_lucky(length):
    half = length // 2
    s = ['4'] * half + ['7'] * half
    random.shuffle(s)
    return ''.join(s)

def generate_test_case():
    t = 10000
    print(t)
    for _ in range(t):
        if random.random() < 0.2:
            # Edge cases: super lucky numbers or numbers around them
            if random.choice([True, False]):
                length = random.choice([2, 4, 6, 8, 10])
                sl = generate_super_lucky(length)
                n = sl
            else:
                length = random.choice([2, 4, 6, 8])
                sl = generate_super_lucky(length)
                delta = random.choice([-1, 1])
                n = str(int(sl) + delta)
        else:
            # Random number with 1 to 9 digits
            length = random.randint(1, 9)
            digits = [str(random.randint(1, 9))]
            for _ in range(length - 1):
                digits.append(str(random.randint(0, 9)))
            n = ''.join(digits)
            n = str(int(n))  # Remove leading zeros
        print(n)

if __name__ == "__main__":
    generate_test_case()
