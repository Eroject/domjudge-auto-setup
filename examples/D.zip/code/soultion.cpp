#include <iostream>
#include <string>
#include <climits>

using namespace std;

string n_str, best;
int l, required_4, required_7;

void backtrack(int pos, int count_4, int count_7, string current, bool is_tight) {
    if (pos == l) {
        if (count_4 == required_4 && count_7 == required_7) {
            if (best.empty() || current < best) {
                best = current;
            }
        }
        return;
    }

    int current_digit = is_tight ? n_str[pos] - '0' : -1;
    for (int d : {4, 7}) {
        if (is_tight && d < current_digit) continue;

        int new_count_4 = count_4 + (d == 4);
        int new_count_7 = count_7 + (d == 7);

        if (new_count_4 > required_4 || new_count_7 > required_7) continue;

        int remaining = l - pos - 1;
        int needed_4 = max(required_4 - new_count_4, 0);
        int needed_7 = max(required_7 - new_count_7, 0);

        if (needed_4 + needed_7 > remaining) continue;

        bool new_is_tight = is_tight && (d == current_digit);
        backtrack(pos + 1, new_count_4, new_count_7, current + (char)(d + '0'), new_is_tight);
    }
}

string minimal_super_lucky(string num) {
    n_str = num;
    l = n_str.size();
    required_4 = l / 2;
    required_7 = l / 2;
    best.clear();

    backtrack(0, 0, 0, "", true);
    return best;
}

int main() {
    string n;
    cin >> n;
    int len = n.size();

    if (len % 2 != 0) {
        int half = (len + 1) / 2;
        cout << string(half, '4') + string(half, '7') << endl;
    } else {
        string res = minimal_super_lucky(n);
        if (!res.empty()) {
            cout << res << endl;
        } else {
            int new_len = len + 2;
            cout << string(new_len / 2, '4') + string(new_len / 2, '7') << endl;
        }
    }

    return 0;
}
