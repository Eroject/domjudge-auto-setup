#include <bits/stdc++.h>
using namespace std;
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long r, h;
    cin >> r >> h;

    // a = r/2  (balloon radius)
    // 1) rectangular grid: rows spaced 2a = r, each row holds 2 balloons
    //    number of full rows n = floor((h + a)/(2a)) = floor((2h + r)/(2r))
    long long n = (2*h + r) / (2*r);

    // 2) triangular stack above those n rows:
    //    vertical spacing between triangular rows = a*sqrt(3) = r*sqrt(3)/2
    long double delta = (long double)r * sqrtl((long double)3) / 2.0L;

    //    remaining height for triangular stacking:
    //    from top of last grid‐row (at z = a + (n-1)*r) up to z_max = h + (r - a)
    //    numerator = (h + r - n*r)
    long double numer = (long double)h + (long double)r - (long double)n * (long double)r;

    //    how many triangular rows of 1 balloon fit:
    long long m = 0;
    if (numer > 0) {
        m = (long long)floor(numer / delta + 1e-12L);
        if (m < 0) m = 0;
    }

    // total balloons = 2 per grid row + 1 per triangular row
    long long ans = 2*n + m;
    cout << ans << "\n";
    return 0;
}
