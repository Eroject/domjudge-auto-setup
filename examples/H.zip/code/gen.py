#!/usr/bin/env python3
import random
import sys

def set_deterministic():
    """Assure des résultats reproductibles"""
    random.seed(42)  # Graines fixes pour la reproductibilité
    if sys.version_info >= (3, 11):
        random.randbytes(1)  # Nécessaire pour la pleine détermination dans Python 3.11+

def generate_test_case(r_max=10**7, h_max=10**7):
    r = random.randint(1, r_max)
    h = random.randint(1, h_max)
    print(r, h)

def main():
    set_deterministic()

    # Correction : passer explicitement des valeurs à la fonction generate_test_case
    generate_test_case()  # Ici, aucune variable `t` n'est utilisée

if __name__ == "__main__":
    main()
