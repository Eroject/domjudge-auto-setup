#!/bin/bash


# Small test cases
python3 gen.py   > ../data/secret/01.in
python3 gen.py  > ../data/secret/02.in

# Medium test cases
python3 gen.py > ../data/secret/03.in
python3 gen.py  > ../data/secret/04.in

# Large test cases with known primes
python3 gen.py  > ../data/secret/05.in
python3 gen.py > ../data/secret/06.in
python3 gen.py > ../data/secret/07.in
python3 gen.py > ../data/secret/08.in
python3 gen.py > ../data/secret/09.in
python3 gen.py > ../data/secret/10.in