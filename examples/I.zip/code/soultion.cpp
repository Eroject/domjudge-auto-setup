#include <iostream>
#include <vector>
#include <map>
using namespace std;

void solve() {
    int n, x, y;
    cin >> n >> x >> y;
    vector<int> a(n);
    for (int i = 0; i < n; i++) cin >> a[i];
    
    map<pair<int,int>, int> cnt;
    long long res = 0;
    
    for (int num : a) {
        int rx = num % x;
        int ry = num % y;
        res += cnt[{(x - rx) % x, ry}];
        cnt[{rx, ry}]++;
    }
    
    cout << res << '\n';
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t;
    cin >> t;
    while (t--) {
        solve();
    }
    
    return 0;
}