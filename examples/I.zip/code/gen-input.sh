#!/bin/bash
python3 gen.py 4 10 100 100 > ../data/secret/01.in
python3 gen.py 4 100 1000 1000 > ../data/secret/02.in
python3 gen.py 100 1000 100000 100000 > ../data/secret/03.in
python3 gen.py 100 10000 1000000 1000000 > ../data/secret/04.in
python3 gen.py 100 200000 1000000000 1000000000 > ../data/secret/05.in
python3 gen.py 100 200000 1000000000 1000000000 > ../data/secret/06.in