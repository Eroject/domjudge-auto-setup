#!/usr/bin/env python3
import random
import sys

def set_deterministic():
    """Ensure reproducible results"""
    random.seed(42)  # Fixed seed
    if sys.version_info >= (3, 11):
        random.randbytes(1)  # Python 3.11+ needs this for full determinism

def generate_test_case(t, n_max=2*10**5, xy_max=10**9, a_max=10**9):
    print(t)
    for _ in range(t):
        n = random.randint(2, min(n_max, 2*10**5))
        x = random.randint(1, xy_max)
        y = random.randint(1, xy_max)
        a = [random.randint(1, a_max) for _ in range(n)]
        print(n, x, y)
        print(' '.join(map(str, a)))

def main():
    if len(sys.argv) != 5:
        print("Usage: python gen.py [t] [max_n] [max_xy] [max_a]")
        print("Example: python gen.py 100 200000 1000000000 1000000000")
        sys.exit(1)

    set_deterministic()

    t = int(sys.argv[1])
    max_n = int(sys.argv[2])
    max_xy = int(sys.argv[3])
    max_a = int(sys.argv[4])

    generate_test_case(t, max_n, max_xy, max_a)

if __name__ == "__main__":
    main()