#include <iostream>
#include <vector>

using namespace std;

typedef long long ll;
typedef long double ld;

#define fastInp cin.tie(0); cout.tie(0); ios_base::sync_with_stdio(0);

vector<ll> vec;
ll n;

const ll CHECK = 512;

int solve() {

	cin >> n;

	vec.resize(n);
	for (auto& c : vec) cin >> c;

	vector<ll> dp(1);

	ll bst = 0;
	for (int i = 0; i < n; i++) {
		ll cur = 0;
		dp.push_back(1);
		for (int j = i - 1; j >= max(0ll, i - CHECK); j--) {
			if ((vec[i] ^ j) > (vec[j] ^ i)) {
				dp.back() = max(dp.back(), dp[j + 1] + 1);
			}
		}

		bst = max(bst, dp.back());
	}

	cout << bst << "\n";

	return 0;
}

int main(){
    fastInp;
    int t;
    cin >> t;
    while(t--) solve();
}
