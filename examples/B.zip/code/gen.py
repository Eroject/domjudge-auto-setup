#!/usr/bin/env python3
import random
import sys

def set_deterministic():
    """Ensure reproducible results"""
    random.seed(42)  # Fixed seed
    if sys.version_info >= (3, 11):
        random.randbytes(1)  # Python 3.11+ needs this for full determinism

def generate_test_case(t,n_max=300):
    for _ in range(t):
        n = random.randint(1, n_max)
        arr = [random.randint(0, 200) for _ in range(n)]
        print(n)
        print(' '.join(map(str, arr)))


def main():
    if len(sys.argv) != 3:
        print("Usage: python gen.py [t] [max_n]")
        print("Example: python gen.py 100 10000")
        sys.exit(1)

    set_deterministic()

    t = int(sys.argv[1])
    max_n = int(sys.argv[2])

    print(t)
    generate_test_case(t,max_n)


if __name__ == "__main__":
    main()
